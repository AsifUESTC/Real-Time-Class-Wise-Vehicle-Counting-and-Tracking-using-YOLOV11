### YOLOv11 for Real-Time Class-Wise Vehicle Counting and Tracking

#### Tutorial: https://youtu.be/o8S28sLOUU8

![Untitled](https://github.com/user-attachments/assets/b415b2f5-715b-4e34-9974-3227040fc37b)
